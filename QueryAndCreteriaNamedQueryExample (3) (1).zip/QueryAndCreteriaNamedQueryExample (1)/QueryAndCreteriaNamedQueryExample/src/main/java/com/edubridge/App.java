package com.edubridge;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.TypedQuery;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

/**
 * Hello world!
 *
 */
public class App 
{
	static Configuration cfg=null;
	static SessionFactory factory=null;
	static Session session=null;
	static Transaction tx=null;
	static Criteria criteria=null;
	static 
	{
		  cfg=new Configuration();
		    cfg.configure("hibernate.cfg.xml");//populates the data of the configuration file  
		  factory=cfg.buildSessionFactory();  
		     session=factory.openSession();
	}
    public static void main( String[] args )
    {
    	Scanner scanner =new Scanner(System.in);
    	char ch=' ';
    	try{
    		
    		do {
    			System.out.println("1--Insert /n 2--update /n 3--delete /n 4--search by name /n 5-search by price range");
    			System.out.println("Enter the option");
    			int option=scanner.nextInt();
    			switch(option)
    			{
    			case 1:
    				System.out.println("Enter the prname,prprice and quantity");
    				
    				insertData(scanner.next(),scanner.nextFloat(),scanner.nextInt());
    				break;
    			case 2: 
    				System.out.println("enter the product ID To update and new name of product  and enter the updated price" );
    				
    				updateData(scanner.nextInt(),scanner.next(),scanner.nextFloat());
    				break;
    			case 3: 
    				System.out.println("enter the product ID To delete");
    				
    				deleteData(scanner.nextInt());
    				break;
    			case 4: 
    				System.out.println("enter the product name to search");
    				
    				searchByProductName(scanner.next());
    				break;
    			case 5: 
    				System.out.println("enter the product price range to search the product");
    				
    				searchByProductPriceRange(scanner.nextFloat(),scanner.nextFloat());
    				break;
    				
    			case 6:
    				System.out.println("enter the quantity 1 and quantity 2");
    				 searchProductByQuantityRange(scanner.nextInt(),scanner.nextInt());
    				 break;
    				 
    				default: System.out.println("Enter the valid option");
    				
    			}		
    			System.out.println("Do you wish to continue then press yes ");
    			ch=scanner.next().charAt(0);
    		
    			
    		}while(ch=='y'||ch=='Y');
    		
    	}catch(Exception ex)
    	{
    		System.out.println(ex.getMessage());
    	}
        
    }
	private static void searchByProductPriceRange(float price1, float price2) {
		// TODO Auto-generated method stub
		

		criteria=session.createCriteria(Product.class);
		criteria.add(Restrictions.between("price", price1, price2));
		List<Product> plist=criteria.list();
		System.out.println(plist);
		Iterator<Product> iterator = plist.iterator();
		while(iterator.hasNext())
		{
			Product product = iterator.next();
			
			System.out.println("id" + product.getP_id() + " name" + product.getpName() + " price" + product.getPrice());
		}
	}
		
	// TODO Auto-generated method stub
			//Inside the method, a new criteria object is created using the "createCriteria" method on the session object. The criteria object is associated with the "Product" class, which is the class that represents the product data in the database.
			//The "add" method is called on the criteria object to add a search condition to the query. The search condition is created using the "Restrictions" class and specifies that the product name ("pName" property) should be equal to the value of the "name" parameter.
			//The "list" method is called on the criteria object to execute the query and retrieve a list of matching products.		
	        //The list of matching products is printed to the console using the "System.out.println" method.

//An iterator is created for the list of products using the "iterator" method.

//A while loop is used to iterate through each product in the list.

//Inside the loop, the current product is retrieved using the "next" method of the iterator.

//The ID, name, and price of the current product are printed to the console using the "System.out.println" method.
	
	
	private static void searchByProductName(String name) {
		
		criteria=session.createCriteria(Product.class);
		criteria.add(Restrictions.eq("pName", name));
	    List<Product> plist=criteria.list();
		System.out.println(plist);
		Iterator<Product> iterator = plist.iterator();
		while(iterator.hasNext())
		{
			Product product = iterator.next();
			
			System.out.println("id" + product.getP_id() + " name"+product.getpName()+ " price" + product.getPrice());
		}
	}
	private static void deleteData(int productId) {
		Product product = session.get(Product.class, productId);
	    tx = session.beginTransaction();
	    session.delete(product);
	    tx.commit();
		
	}
	private static void updateData(int pid, String prName,Float price) {
		 Product product = session.get(Product.class, pid);
		    if (product != null) {
		        product.setpName(prName);
		        product.setPrice(price);
		        tx = session.beginTransaction();
		        session.update(product);
		        tx.commit();
		    }
	
		
	}
	
	//The method is named "insertData" and takes two parameters: a string named "name" and a float named "price".
    //Inside the method, a new instance of the "Product" class is created using the default constructor
//The "setpName" method is called on the product object and passed the "name" parameter to set the name of the product.
//The "setPrice" method is called on the product object and passed the "price" parameter to set the price of the product.
//The "beginTransaction" method is called on the session object to start a new transaction.
//The "save" method is called on the session object and passed the product object to save the product data to the database.
//The "commit" method is called on the transaction object to commit the changes to the database.
	
	private static void insertData(String name, float price,int quantity) {
		// TODO Auto-generated method stub
	Product product =new Product();
	product.setpName(name);
	product.setPrice(price);
	product.setQuantity(quantity);
	tx=session.beginTransaction();
	session.save(product);
	tx.commit();
	}
	
	private static void searchProductByQuantityRange(int q1,int q2)
	{
		TypedQuery query= session.getNamedQuery("findproductbyquantityrange");
		query.setParameter("q1",q1);
		query.setParameter("q2",q2);
		 List<Product> productlist = query.getResultList();
		 Iterator<Product> iterator = productlist.iterator();
			while(iterator.hasNext())
			{
				Product product = iterator.next();
				
				System.out.println("id" + product.getP_id() + " name"+product.getpName()+ " price" + product.getPrice());
				System.out.println(product.getQuantity());
			}
		
	}
}
