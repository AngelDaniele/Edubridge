package com.edubridge;

public class Customer {
	
	private int custId;
	private String customerName;
	//private Address address;
	
	Customer()
	{
		
	}

	public Customer(int custId, String customerName) {
		super();
		this.custId = custId;
		this.customerName = customerName;
		
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", customerName=" + customerName + " ]";
	}

	

}
