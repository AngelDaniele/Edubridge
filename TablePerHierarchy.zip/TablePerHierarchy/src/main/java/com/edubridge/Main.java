package com.edubridge;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;



public class Main 
{
    public static void main( String[] args) {
    	System.out.println("Storing the data");
		try {
			Configuration cfg = new Configuration();

			cfg.configure("hibernate.cfg.xml");// populates the data of the configuration file

			// creating seession factory object
			SessionFactory factory = cfg.buildSessionFactory();
			Session session = factory.openSession();

			// creating transaction object
			Transaction t = session.beginTransaction();

		   Employee emp = new Employee();

		  // emp.setId(10);

		   emp.setName("Angel");
		   
		   
		   RegularEmployee remp = new RegularEmployee();
		   
		   remp.setName("Messi");
		   remp.setSalary(60000);
		   remp.setBonus(10000);
		   
		   
		   ContractEmployee cemp = new ContractEmployee();
		   
		   cemp.setName("Kanishka");
		   cemp.setPayPerhr(5000);
		   cemp.setContractDuration(6);

			session.persist(emp);// persisting the object
			session.persist(remp);
			session.persist(cemp);
			
			t.commit();// transaction is committed

			/* Serializable id=session.save(t1); */

			session.close();

			System.out.println("successfully saved");
		} catch (Exception ex) {
			System.out.println("Problem in connection" + ex.getMessage());
		}
	
    }
}
