package com.edubridge;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;


@Entity
@DiscriminatorValue(value="Conemployee")

public class ContractEmployee extends Employee {

	
	private float payPerhr;
	private int contractDuration;
	
	
	public float getPayPerhr() {
		return payPerhr;
	}
	public int getContractDuration() {
		return contractDuration;
	}
	public void setPayPerhr(float payPerhr) {
		this.payPerhr = payPerhr;
	}
	public void setContractDuration(int contractDuration) {
		this.contractDuration = contractDuration;
	}
	
}
