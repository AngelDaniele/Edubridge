package com.edubridge;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Storing the data");
		try {
			Configuration cfg = new Configuration();

			cfg.configure("hibernate.cfg.xml");// populates the data of the configuration file

			// creating seession factory object
			SessionFactory factory = cfg.buildSessionFactory();
			Session session2 = factory.openSession();

			// creating transaction object
			Transaction t2 = session2.beginTransaction();

			Address ad=new Address();
			ad.setStreet("Swarnapuri");
			ad.setCity("salem");
			ad.setState("Tamil Nadu");
			ad.setPincode("636008");
			
			
			
			
            UserDetails ud=new UserDetails();
            ud.setUserName("Angel");
            ud.setAddress(ad);
           
            ud.setDob(new Date());
            ud.setPhone(1234567890);
            
            
            
            
			session2.persist(ud);// persisting the object

			t2.commit();// transaction is committed

			/* Serializable id=session.save(t1); */

			session2.close();

			System.out.println("successfully saved");
		} catch (Exception ex) {
			System.out.println("Problem in connection" + ex.getMessage());
		}
	

	}

}
