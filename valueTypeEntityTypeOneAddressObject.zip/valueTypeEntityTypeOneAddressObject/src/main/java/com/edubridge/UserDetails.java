package com.edubridge;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "User_Details")

public class UserDetails {
	@Id @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name="USER_ID")
     private long userId;
     @Column(name="USER_NAME")
      private String userName;
      @Column(name="USER_PHONE")
      private long phone;
     @Column(name="DOB")
      private Date dob;
     
     //creating instance of the address class
     @Embedded 
     private Address address;
     
     
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}

}
