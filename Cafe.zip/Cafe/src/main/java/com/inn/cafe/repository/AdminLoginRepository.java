package com.inn.cafe.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.inn.cafe.model.Admin;

public interface AdminLoginRepository extends JpaRepository<Admin,Integer> {
	
	public Admin findByEmail(String email);
	
	
	
	
	
	
	
	
	
	

}
