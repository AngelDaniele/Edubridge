package com.inn.cafe.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.inn.cafe.model.Admin;
import com.inn.cafe.service.AdminLoginService;

@RestController
public class AdminLoginController {
	
	@Autowired
	AdminLoginService adminLoginService;
	
	@PostMapping("/signupUser")
	public  Admin saveAdmin(@RequestBody Admin admin) throws Exception {
		
		String tempEmailId=admin.getEmail();
		if(tempEmailId != null && !"".equals(tempEmailId)) {
			
			Admin adminobj=adminLoginService.fetchUserByEmailId(tempEmailId);
			if(adminobj !=null)
			{
				throw new Exception("User with +tempEmailId+ Already Exists");
			}
			
			
			adminobj= adminLoginService.saveAdmin(admin);
				
			return adminobj;
			
			
		
			
			
		}
		return admin;
		
		
		
		
		
	}
	
	
	

}
