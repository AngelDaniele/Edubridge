import java.util.*;
public class FileExtension {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter");
	    String s1 = sc.nextLine();
	    System.out.println(extensionString(s1));
		

	}
	public static String extensionString(String s1) {
	    StringTokenizer t = new StringTokenizer(s1, ".");
	    t.nextToken();
	   
	    String s2 = t.nextToken();
	    return s2;
	  }

}
