package com.student.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.student.connection.GetConnection;
import com.student.table.Student;

public class StudentTest {

	public static void insertStudent(Student student) throws SQLException {

		String sql = "insert into studentdetails values(?,?,?)";
		PreparedStatement ps = GetConnection.getConnection().prepareStatement(sql);
		ps.setInt(1, student.getStudentid());
		ps.setDouble(2, student.getStudentmarks());
		ps.setString(3, student.getStudentemail());
		int res = ps.executeUpdate();

	}

	public static void deleteStudent(int studentid1) throws SQLException {

		String sql = "delete from studentdetails where stuid= ?";
		PreparedStatement ps = GetConnection.getConnection().prepareStatement(sql);
		ps.setInt(1, studentid1);
		int res = ps.executeUpdate();

	}

	public static void updateStudent(int studentid, String studentemail) throws SQLException {

		String sql = "update studentdetails set studentemail = ? where stuid = ?";
		PreparedStatement ps = GetConnection.getConnection().prepareStatement(sql);
		ps.setString(1, studentemail);
		ps.setInt(2, studentid);
		int res = ps.executeUpdate();

	}

	public static void main(String[] args) throws SQLException {

		Scanner scanner = new Scanner(System.in);
		System.out.println("enter choice");
		System.out.println("1.  create data");
		System.out.println("2.  remove data");
		System.out.println("3.  update data");
		System.out.println("4.  display data");
		System.out.println("choose the option");
		int option = scanner.nextInt();

		switch (option) {
		case 1:

			System.out.println("enter the number of student u want to add:");
			int count = scanner.nextInt();
			for (int i = 1; i <= count; i++) {
				System.out.println("enter the student id :");
				int studentid = scanner.nextInt();

				System.out.println("enter the student salary:");
				double studentmarks = scanner.nextDouble();
				System.out.println("enter the student email:");
				String studentemail = scanner.next();
				Pattern p = Pattern.compile("^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@"
						+ "[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$");
				Matcher m = p.matcher(studentemail);
				boolean result = m.matches();
				if (result == true) {

					Student student = new Student(studentid, studentmarks, studentemail);

					insertStudent(student);

					System.out.println(" student inserted successfully");

				} else {
					System.out.println(" enter the valid email");

				}
			}

			break;

		case 2:
			System.out.println("enter the student id to delete :");
			int studentid1 = scanner.nextInt();

			deleteStudent(studentid1);
			System.out.println(" student deleted successfully");
			break;

		case 3:
			System.out.println("Enter records for updation");
			System.out.println("enter the updated student email :");
			String studentemail = scanner.next();

			Pattern p = Pattern.compile("^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@"
					+ "[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$");
			Matcher m = p.matcher(studentemail);
			boolean result = m.matches();
			if (result == true) {

				System.out.println("enter the student id :");
				int studentid = scanner.nextInt();

				updateStudent(studentid, studentemail);
				System.out.println(" student updated successfully");
			} else {
				System.out.println(" enter the valid email");
			}

			break;

		}
	}
}
