package com.student.table;

public class Student {
	
	private int studentid;
	private double  studentmarks;
	private String studentemail;
	
	public Student()
	{
		
	}
	
	
	public Student(int studentid, double studentmarks, String studentemail) {
		super();
		this.studentid = studentid;
		this.studentmarks = studentmarks;
		this.studentemail = studentemail;
	}
	
	
	
	@Override
	public String toString() {
		return "Student [studentid=" + studentid + ", studentmarks=" + studentmarks + ", studentemail=" + studentemail
				+ "]";
	}
	public int getStudentid() {
		return studentid;
	}
	public void setStudentid(int studentid) {
		this.studentid = studentid;
	}
	public double getStudentmarks() {
		return studentmarks;
	}
	public void setStudentmarks(double studentmarks) {
		this.studentmarks = studentmarks;
	}
	public String getStudentemail() {
		return studentemail;
	}
	public void setStudentemail(String studentemail) {
		this.studentemail = studentemail;
	}

}
