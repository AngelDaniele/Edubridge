package com.edubridge;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller 
public class HelloController {
	
	
	@RequestMapping("/hello")  
    
    public String display(@RequestParam("name") String uname,@RequestParam("pass") String upass,Model m)  
    {  
   if(upass.equals("admin"))  
        {  
            String msg="Hello "+uname;  
            //add a message to the model  
            m.addAttribute("message", msg);  
            return "viewpage";  
        }  
        else  
        {  
            String msg="Sorry "+uname+". You entered an incorrect password";  
        m.addAttribute("message", msg);  
            return "errorpage";  
    }     
    }  

}
