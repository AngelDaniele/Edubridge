
public class ExceptionHandling {

	public static void main(String[] args) {
		try {
			int num=18/0;
		}catch(ArithmeticException ex)
		{
			System.out.println("child exception");
		}catch(Exception ex)
		{
			System.out.println("base exception");
		}
		
	}

}
