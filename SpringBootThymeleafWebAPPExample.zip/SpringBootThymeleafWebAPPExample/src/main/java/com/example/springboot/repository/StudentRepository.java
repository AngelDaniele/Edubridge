package com.example.springboot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springboot.entity.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {
	List<Student> findByName(String name);//select *from student where name='somename'
	//save(),findAll(),fingById(),delete()
	
	
	
	
	
	
	
	
	

}
  