package com.example.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootThymeleafWebAppExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootThymeleafWebAppExampleApplication.class, args);
	}

}
