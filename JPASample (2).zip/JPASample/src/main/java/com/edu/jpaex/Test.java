package com.edu.jpaex;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;





public class Test {
	private static EntityManagerFactory emf= null;
	  private static 	EntityManager manager=null;
	  
	  static {
		  emf= Persistence.createEntityManagerFactory("Test");
		  manager=emf.createEntityManager();
	  }
	  public static void main( String[] args )
	 
	    {
		  
		  Scanner scanner = new Scanner(System.in);
	        char ch=' ';
	    	
	    	
	    	
	        do {
	        	
		    	System.out.println("1--Insert /n 2--update /n 3--delete /n 4--search by name /n 5-search by id");
				System.out.println("Enter the option");
				int option=scanner.nextInt();
	        	
	        	switch(option)
	        	{
	        	
	        	case 1:
	        		System.out.println("enter the aid , aname and atech:");
	        		insertData(scanner.nextInt(),scanner.next(),scanner.next());
	        		System.out.println(" Inserted successfully");
	        		break;
	        		
	        	case 2:
	        		System.out.println("enter the aid , aname and atech:");
	        		updateData(scanner.nextInt(),scanner.next(),scanner.next());
	            	break;
	            	
	        	case 3:
	        		System.out.println("enter the aid");
	        		deleteData(scanner.nextInt());
	        		break;
	        	case 4:
	        		System.out.println("enter  aname :");
	        		findByName(scanner.next());
	        		
	        		break;
	        		
	        	case 5:
	        		System.out.println("enter  aid :");
	        		findById(scanner.nextInt());
	        		break;
	        	
	        	}
	        	
	        	
	        	
	        	
	        	System.out.println("enter y or Y to continue");
	        	ch=scanner.next().charAt(0);
	        	
	        }while(ch=='y'||ch=='Y');
	        
	     
	    	
	    

	    
	    
	    	
	    	
	    	
	    }








private static void insertData(int aid, String aName, String atech) {
	
	Alien alien = new Alien();
	alien.setAid(aid);
	alien.setaName(aName);
	alien.setAtech(atech);
    manager.getTransaction().begin();
	manager.persist(alien);
	manager.getTransaction().commit();
	 
 }

private static void findByName(String aName)
{
	
	Query query = manager.createNamedQuery("findAlienbyname");
	query.setParameter("name",aName);
	List<Alien> alienList=query.getResultList();
	
	for(Alien alien:  alienList)
	{
		System.out.println(alien);
		
	}
	
}
private static void updateData(int aid, String aName, String atech) {
   

    manager.getTransaction().begin();
    Alien alien = manager.find(Alien.class, aid); // find the Alien entity by ID
    if (alien != null) {
        alien.setaName(aName); // update the name
        alien.setAtech(atech); // update the technology
        manager.merge(alien); // save the changes to the database
    }
    manager.getTransaction().commit();

   
}

private static void deleteData(int aid) {
   
    
    Alien alien = manager.find(Alien.class, aid);
    if (alien != null) {
        manager.getTransaction().begin();
        manager.remove(alien);
        manager.getTransaction().commit();
    }
    
    
}
private static void findById(int aid)
{	
    Alien alien=manager.find(Alien.class,aid);
    System.out.println(alien);

	
}
}








