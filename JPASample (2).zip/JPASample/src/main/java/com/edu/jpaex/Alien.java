package com.edu.jpaex;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@NamedQueries(
		{
		@NamedQuery(
				
				name="findAlienbyname",
				query="from Alien a where a.aName =:name  "
				
				
				
				
				)
		
		}
		
		
		
)

@Entity

public class Alien {
	
	    @Id
	
		
		private int aid;
		
		private String aName;
		private String atech;
		
		
		
		public Alien()
		{
			super();
		}
		
		public int getAid() {
			return aid;
		}
		public void setAid(int aid) {
			this.aid = aid;
		}
		public String getaName() {
			return aName;
		}
		public void setaName(String aName) {
			this.aName = aName;
		}
		public String getAtech() {
			return atech;
		}
		public void setAtech(String atech) {
			this.atech = atech;
		}
		@Override
		public String toString() {
			return "Alien [aid=" + aid + ", aName=" + aName + ", atech=" + atech + "]";
		}
		
		
		
}
		