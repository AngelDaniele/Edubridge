package loginpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();
		System.out.println("11111111111111111");
		try {
			String userName=request.getParameter("username");
			String password=request.getParameter("password");
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/servlet","root","angeldaniele");
		PreparedStatement stat=con.prepareStatement("select *from user where username=? and password=?");
		
		stat.setString(1,userName);
		stat.setString(2,password);
	
		ResultSet rs=stat.executeQuery();
		if(rs.next())
		{
			out.println("<p style='color:red'>welcome to login page</p>" );
			out.println("found user and logged in successfully...<p style='color:blue'>"+userName+"</p>");
		}else
			out.println("wrong details");
		out.println("<a href = 'Login.html'>Login</a>");
		
		}catch(Exception ex)
		{
			System.out.println("8888888888888"+ex.getMessage());
		}
	}

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		doGet(request, response);
	}

}
