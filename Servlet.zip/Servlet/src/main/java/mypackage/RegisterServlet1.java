package mypackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlet1
 */
public class RegisterServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();
		System.out.println("11111111111111111");
		try {
			String userName=request.getParameter("username");
			String password=request.getParameter("password");
			String cpassword=request.getParameter("conpassword");
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/servlet","root","angeldaniele");
		PreparedStatement stat=con.prepareStatement("insert into user values(?,?,?)");
		int x=100;
		stat.setInt(1,x++);
		stat.setString(2,userName);
		stat.setString(3,password);
		if(password.equals(cpassword)) {
			System.out.println("11111111111111111");
			int res=stat.executeUpdate();
			if(res==1)
				out.println("registered");
		}
		else
			out.println("registration failed");
		}catch(Exception ex)
		{
			System.out.println("8888888888888"+ex.getMessage());
		}
	}
		
		
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		//PrintWriter out = response.getWriter();
		//out.println("DO Post Method");
		doGet(request, response);
	}

}
