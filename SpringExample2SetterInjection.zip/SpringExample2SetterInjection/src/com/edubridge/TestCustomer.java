package com.edubridge;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;


public class TestCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Resource resource =  new ClassPathResource( "Spring-Config.xml "); 
		BeanFactory factory = new XmlBeanFactory(resource);
		Customer customer = (Customer)factory.getBean("customer");
		
		System.out.println(customer);
		
		Customer customer01 = (Customer)factory.getBean("customer1");
		
		System.out.println(customer01);
		
	}

}
