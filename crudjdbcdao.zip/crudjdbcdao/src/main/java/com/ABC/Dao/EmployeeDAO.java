package com.ABC.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.ABC.connection.GetConnection;
import com.ABC.table.Employee;

public class EmployeeDAO {
	/* the class where crud operations are done */

	public static void insertEmployee(Employee employee) throws SQLException {

		String sql = "insert into emplyeedetails values(?,?,?)";
		PreparedStatement ps = GetConnection.getConnection().prepareStatement(sql);
		ps.setInt(1, employee.getEmpid());
		ps.setDouble(2, employee.getEmpsalary());
		ps.setString(3, employee.getEmpemail());
		int res = ps.executeUpdate();

	}

	public static void deleteEmployee(int empid1) throws SQLException {

		String sql = "delete from emplyeedetails where empid= ?";
		PreparedStatement ps = GetConnection.getConnection().prepareStatement(sql);
		ps.setInt(1, empid1);
		int res = ps.executeUpdate();

	}

	public static void updateEmployee(int empid, String empemail) throws SQLException {

		String sql = "update emplyeedetails set empemail = ? where empid = ?";
		PreparedStatement ps = GetConnection.getConnection().prepareStatement(sql);
		ps.setString(1, empemail);
		ps.setInt(2, empid);
		int res = ps.executeUpdate();

	}

	public static Employee displayEmployee(int empid3) throws SQLException {
		Employee employee = null;

		String sql = "select empid,empsalary,empemail from emplyeedetails where empid= ?";
		PreparedStatement ps = GetConnection.getConnection().prepareStatement(sql);
		ps.setInt(1, empid3);

		ResultSet rs = ps.executeQuery();
		System.out.println(rs.next());

		employee = new Employee();
		employee.setEmpid(rs.getInt(1));
		employee.setEmpsalary(rs.getDouble(2));
		employee.setEmpemail(rs.getString(3));
		System.out.println(employee);

		return employee;

	}

	public static void main(String[] args) throws SQLException {

		Scanner scanner = new Scanner(System.in);
		System.out.println("enter choice");
		System.out.println("1.  create data");
		System.out.println("2.  remove data");
		System.out.println("3.  update data");
		System.out.println("4.  display data");
		System.out.println("choose the option");
		int option = scanner.nextInt();

		switch (option) {
		case 1:
			System.out.println("enter the number of employees u want to add:");
			int count = scanner.nextInt();
			for (int i = 1; i <= count; i++) {
				System.out.println("enter the employee id :");
				int empid = scanner.nextInt();
				System.out.println("enter the employee salary:");
				double empsalary = scanner.nextDouble();
				System.out.println("enter the employee email:");
				String empemail = scanner.next();
				Employee employee = new Employee(empid, empsalary, empemail);

				insertEmployee(employee);

				System.out.println(" employee inserted successfully");

			}
			break;

		case 3:
			System.out.println("Enter records for updation");
			System.out.println("enter the updated employee email :");
			String empemail = scanner.next();
			System.out.println("enter the employee id :");
			int empid = scanner.nextInt();

			updateEmployee(empid, empemail);
			System.out.println(" employee updated successfully");

			break;

		case 2:
			System.out.println("enter the employee id to delete :");
			int empid1 = scanner.nextInt();

			deleteEmployee(empid1);
			System.out.println(" employee deleted successfully");
			break;
		case 4:

			System.out.println("enter the employee id :");
			int empid3 = scanner.nextInt();

			displayEmployee(empid3);

			System.out.println(" employee  displayed successfully");
			break;

		}

	}

}
