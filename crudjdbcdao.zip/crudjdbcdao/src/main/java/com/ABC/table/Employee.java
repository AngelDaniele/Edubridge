package com.ABC.table;

public class Employee {
	
	/*  the class where fields are declared as per the employeedetails table in the ABC database in mysql  */
	
	private int empid;
	private double  empsalary;
	private String empemail;
	
	public Employee()
	{
		
	}
	
	
	public Employee(int empid, double empsalary, String empemail) {
		super();
		this.empid = empid;
		this.empsalary = empsalary;
		this.empemail = empemail;
	}
	
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public double getEmpsalary() {
		return empsalary;
	}
	public void setEmpsalary(double empsalary) {
		this.empsalary = empsalary;
	}
	public String getEmpemail() {
		return empemail;
	}
	public void setEmpemail(String empemail) {
		this.empemail = empemail;
	}


	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empsalary=" + empsalary + ", empemail=" + empemail + "]";
	}
	
	

}
