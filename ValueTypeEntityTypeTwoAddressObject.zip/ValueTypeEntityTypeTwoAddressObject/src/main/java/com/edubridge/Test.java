package com.edubridge;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Storing the data");
		try {
			Configuration cfg = new Configuration();

			cfg.configure("hibernate.cfg.xml");// populates the data of the configuration file

			// creating seession factory object
			SessionFactory factory = cfg.buildSessionFactory();
			Session session2 = factory.openSession();

			// creating transaction object
			Transaction t2 = session2.beginTransaction();

			//just created the object for the address.ad is the refer variable for address 
			// ad reference variable is passed to the userdetails in 49th line
			Address ad=new Address();
			ad.setStreet("Swarnapuri");
			ad.setCity("salem");
			ad.setState("Tamil Nadu");
			ad.setPincode("636008");
			
			
			//just created the object for the permanent address.pa is the refer variable for address
			// pa reference variable is passed to the userdetails in 50th line
			Address pa=new Address();
			pa.setStreet("kodampakkam");
			pa.setCity("chennai");
			pa.setState("Tamil Nadu");
			pa.setPincode("636004");
			
			
			
			//just creating the object for the user detaisl and passing the values
			//inside user details table we have passed ad ie address table and  pa permanet address 
			// passed as a objects. which means table inside table
            UserDetails ud=new UserDetails();
            ud.setUserName("Angel");
            ud.setAddress(ad);
            ud.setPermanentAddress(pa);
            ud.setDob(new Date());
            ud.setPhone(1234567890);
            
            
            
            
			session2.persist(ud);// persisting the object

			t2.commit();// transaction is committed

			/* Serializable id=session.save(t1); */

			session2.close();

			System.out.println("successfully saved");
		} catch (Exception ex) {
			System.out.println("Problem in connection" + ex.getMessage());
		}
	

	}

}
