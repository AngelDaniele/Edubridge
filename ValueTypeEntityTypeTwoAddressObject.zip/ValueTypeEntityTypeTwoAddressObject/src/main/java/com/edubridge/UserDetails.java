package com.edubridge;

import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "User_Details")

public class UserDetails {
	@Id @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name="USER_ID")
     private long userId;
     @Column(name="USER_NAME")
      private String userName;
     @Column(name="USER_PHONE")
      private long phone;
     @Column(name="DOB")
      private Date dob;
     
     //creating instance of address class
     @Embedded
     private Address address;
     
   // line no 42 creating one more object of the address 
   //line no 36 to 41 overriding .bcoz we have 2 object (address and permanent address) with similar column name  
     @Embedded
     @AttributeOverrides({
 	    @AttributeOverride(name="street", column=@Column(name="HOME_STREET_NAME")),
 	    @AttributeOverride(name="city", column=@Column(name="HOME_CITY_NAME")),
 	    @AttributeOverride(name="state", column=@Column(name="HOME_STATE_NAME")),
 	    @AttributeOverride(name="pincode", column=@Column(name="HOME_PIN_CODE"))
 	    })
     private Address PermanentAddress;
     
     
    //setters and getters of permanent address 
	public Address getPermanentAddress() {
		return PermanentAddress;
	}
	public void setPermanentAddress(Address permanentAddress) {
		PermanentAddress = permanentAddress;
	}
	
	
	//setters and getters of userdetails properties
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}

}
