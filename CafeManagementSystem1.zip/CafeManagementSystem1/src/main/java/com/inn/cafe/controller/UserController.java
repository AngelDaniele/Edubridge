package com.inn.cafe.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.inn.cafe.model.User;
import com.inn.cafe.service.UserService;

@RestController
@RequestMapping(path="/user")
public class UserController {
	
	@Autowired
	UserService userService;
	
	public ResponseEntity<String>signUp(@RequestBody(required= true) Map<String,String> user  )
	{
		try {
			
			return userService.signup(user);
			
		}catch(Exception ex){
			
			ex.printStackTrace();
			
		}
		return new ResponseEntity<String>("something went wrong",HttpStatus.INTERNAL_SERVER_ERROR);
		 
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}



