package com.inn.cafe.service;

import java.util.Map;
import java.util.logging.Logger;

import org.hibernate.annotations.common.util.impl.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;


@Service
public class UserServiceImpl {
	
	
	public ResponseEntity<String> signup(Map<String, String> user) {
		// TODO Auto-generated method stub
		   //log.info("Inside signup {}", user);
		if(validateSignUp(user))
		{
			
		}else {
			return new ResponseEntity<String>("Invalid data",HttpStatus.BAD_REQUEST);
		}
		return null;
		
	}
	
	
	private boolean validateSignUp(@RequestBody(required= true) Map<String,String> user)
	{
		if(user.containsKey("name")&&user.containsKey("contactNumber") && user.containsKey("email") && user.containsKey("password"))
		{
			return true;
		}
	    return false;
	    
		
	}

}
