package com.inn.cafe.service;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

@Service
public interface UserService {

	public ResponseEntity<String> signup(Map<String, String> user) ;
	

	
	 boolean validateSignUp(@RequestBody(required= true) Map<String,String> user);
	

}
