package com.inn.cafe.constants;

public class UserConstants {
	
	public static final String SOMETHING_WENT_WRONG = "something went wrong";
	
	public static final String INVALID_DATA = "Invalid Data";

}
