package com.project.model;

public enum CategoryEnum {
		
	MOBILES,BOOKS,CLOTHS,FRUITS,VEGETABLES,ELECTRONICS
}
