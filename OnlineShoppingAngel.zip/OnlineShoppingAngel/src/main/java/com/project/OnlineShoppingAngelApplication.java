package com.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineShoppingAngelApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineShoppingAngelApplication.class, args);
	}

}
