package snippet;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.ABC.connection.GetConnection;
import com.ABC.table.Employee;

public class Snippet {
	public static void main(String[] args) {
		public Employee displayEmployee(int empid3) {
			try {
				String sql = "select empid,empsalary,empemail from employeedetails where empid= ?";
				PreparedStatement ps = GetConnection.getConnection().prepareStatement(sql);
				ps.setInt(1, empid3);
				ResultSet rs = ps.executeQuery();
				if (rs.next()) {
					Employee employee = new Employee();
					employee.setEmpid(rs.getInt(1));
					employee.setEmpsalary(rs.getDouble(2));
					employee.setEmpemail(rs.getString(3));

				} 
			} catch (Exception e) {
				// TODO: handle exception
			}
			return null;
			
		}

		public static List<Employee> getEmployess()
		{
			try {
				List<Employee> list = new ArrayList<Employee>();
				String sql = "select empid,empsalary,empemail from employeedetails";
				PreparedStatement ps = GetConnection.getConnection().prepareStatement(sql);
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					Employee employee = new Employee();
					employee.setEmpid(rs.getInt(1));
					employee.setEmpsalary(rs.getDouble(2));
					employee.setEmpemail(rs.getString(3));
					list.add(employee);
					return list;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		return null;
					
			
		}
	}
}









try {
	
	String sql = "select empid, empsalary,empemail from emplyeedetails";
	PreparedStatement ps = GetConnection.getConnection().prepareStatement(sql);
	

	ResultSet rs = ps.executeQuery();
	if (rs.next()) {
		
		int empid1= rs.getInt("empid ");
		double empsalary = rs.getInt("empsalary ");
		String empemail = rs.getString(" empemail");
		Employee employee = new Employee(empid1,empsalary,empemail);
		System.out.println(employee);
		System.out.println("hi");
	} 
	
} catch (Exception e) {
	// TODO: handle exception
} 

