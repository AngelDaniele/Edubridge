package com.jdbc.student;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class StudentDatabase {

	private static Connection connection = null;
	private static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) throws ClassNotFoundException, SQLException{
		StudentDatabase studentDatabase = new StudentDatabase() ;
		
			Class.forName("com.mysql.jdbc.Driver");
			String dbURL = "jdbc:mysql://localhost:3306/jdbc";
			String username ="root" ;
			String password ="angeldaniele" ;
			Connection connection = DriverManager.getConnection(dbURL,username , password);
			System.out.println("enter choice");
			System.out.println("1.  Insert data");
			int choice = Integer.parseInt(scanner.nextLine()); 
			
			switch(choice)
			{
			case 1:
				studentDatabase.insertRecord();
				break;
			default:
				break;
			}
		

	}
	private void insertRecord() throws SQLException
	{
		System.out.println("inside insert record()");
		
		String sql ="insert into student(name) values('angel')";
		PreparedStatement preparedstatment = connection.prepareStatement(sql);
		int rows = preparedstatment.executeUpdate();
		if(rows>0)
		{
			System.out.println(" Record inserted successfully ");
		}
		
		
	}

}
 