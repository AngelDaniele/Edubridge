package com.example.springboot.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.springboot.model.Student;
import com.example.springboot.service.StudentService;


@RestController
//http://localhost:8089/api/employees/
	@RequestMapping("/api/student/")
public class StudentController {
	
	


		private StudentService studentService;

		public StudentController(StudentService studentService) {
			super();
			this.studentService = studentService;
		}
		//http://localhost:8089/api/
		@PostMapping()
		public ResponseEntity<Student> saveEmployee(@RequestBody Student student)
		{
			System.out.println(student);
			return new ResponseEntity<Student>(studentService.saveStudent(student),HttpStatus.CREATED);
		}
		//http://localhost:8089/api/student
		@GetMapping()
		public List<Student> getAllStudent()
		{
			return studentService.getAllStudent();
		}
		//http://localhost:8089/api/student/2
		@GetMapping("{id}")
		public ResponseEntity<Student> getStudentById(@PathVariable("id") long studentId)
		{
			return new ResponseEntity<Student>(studentService.getStudentById(studentId),HttpStatus.OK);
		}
		//http://localhost:8089/api/student/2
		@PutMapping("{id}")
		public ResponseEntity<Student> updateEmployee(@PathVariable("id") long id, @RequestBody Student student)
		{
			return new ResponseEntity<Student> (studentService.updateStudent(student, id),HttpStatus.OK);
		}
		//http://localhist:8089/api/student/6
		@DeleteMapping("{id}")
		public ResponseEntity<String> deleteEmployee(@PathVariable("id") long id)
		{
			studentService.deleteStudent(id);
			return new ResponseEntity<String>("Student deleted successfully",HttpStatus.OK);
		}

}

