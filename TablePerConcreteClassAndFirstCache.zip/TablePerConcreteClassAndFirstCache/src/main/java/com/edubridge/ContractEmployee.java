package com.edubridge;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Contable")
@AttributeOverrides({
	@AttributeOverride(name = "id", column= @Column(name="con_emp_id")),
	@AttributeOverride(name = "name", column = @Column(name="con_emp_name"))		
})
public class ContractEmployee extends Employee {


	private float pay_per_hour;
	
	
	public float getPay_per_hour() {
		return pay_per_hour;
	}
	public void setPay_per_hour(float pay_per_hour) {
		this.pay_per_hour = pay_per_hour;
	}
	public int getContract_duration() {
		return contract_duration;
	}
	public void setContract_duration(int contract_duration) {
		this.contract_duration = contract_duration;
	}
	@Column(name="contract_duration")
	private int contract_duration;
	
}
