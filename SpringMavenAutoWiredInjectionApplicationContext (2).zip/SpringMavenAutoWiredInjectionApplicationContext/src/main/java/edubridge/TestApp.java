package edubridge;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("edubridge/spring.xml");
		
		Car cobj=(Car)context.getBean("car");
		cobj.drive();
		
	}
}
