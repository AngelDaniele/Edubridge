package edubridge;

public interface Vehicle {
void drive();
}
