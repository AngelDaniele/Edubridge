package com.edubridge;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {
	@GetMapping("login")
	public String dispalyLoginPage() {
		return "login";
		
	}
	
	/*@RequestMapping("/loginpage")
	public String validate(HttpServletRequest req, Model m)
	{
		System.out.println("username passwoersdf");
		String userName=req.getParameter("username");
		String userPassword=req.getParameter("password");
		if(userPassword.equals("1234"))
		{
			String msg= "Hello" + userName +"It is validated successfully";
			m.addAttribute("message",msg);
			return "messagepage";
			
			
		}
		
		else
		{
			String input ="sorry" + userName +"you have entered wrong password";
			m.addAttribute("input",input);
			return "errorpage";
		}
		 
		
	}*/
	@RequestMapping("/loginpage")
	public String validateUser(HttpServletRequest req, Model m) {
		String userName = req.getParameter("username");
		String userPassword = req.getParameter("password");
		if(userPassword.equals("1234")) {
			String message = "Hello " + userName + ", it is validated successfully";
			System.out.println(message);
			m.addAttribute("message", message);
			System.out.println(message);
			return "messagepage";
		} else {
			String input = "Sorry " + userName + ", you have entered the wrong password";
			m.addAttribute("input", input);
			return "errorpage";
		}
	}


}

