package com.edubridge;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/")
public class HelloController {
	
public 	HelloController(){
	
	System.out.println("hello controller");
	
}
@GetMapping("hello")
	public String display() {
	System.out.println("inside method");
		return "viewpage"; 
	}
@GetMapping("helloagain")
public String displayAgain() {
System.out.println("inside method");
	return "final"; 
}
	
	

}
