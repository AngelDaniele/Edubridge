package com.java.tablestudent;
import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;




public class JdbcProject {

	

 
	private static Scanner scanner = new Scanner(System.in);
	private static Object roll_no;
	private static Object Percentage;
	private static Object Name;
public static Statement getStatement() throws ClassNotFoundException, SQLException {
	Class.forName("com.mysql.jdbc.Driver");
	Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "angeldaniele");
	Statement statement=connection.createStatement();
	return statement;
	
}

public static int createData() throws ClassNotFoundException, SQLException{
	Statement statement=getStatement();
	System.out.println("enter the number of students u want to add:");
	int count= scanner.nextInt();
	int res=0;
	for (int i=1;i<=count;i++)
	{
	
	System.out.println("enter the roll_number :");
	int roll_number=scanner.nextInt();
	System.out.println("enter the student name:");
	String name = scanner.next();
	System.out.println("enter the percentage:");
	int percentage= scanner.nextInt();
	String str="insert into Student values('"+roll_number+"','"+name+"','"+percentage +"')";
    res=statement.executeUpdate(str);
	}
	return res;
}

public static int updateData() throws ClassNotFoundException, SQLException
{
	Statement statement=getStatement();
	System.out.println("Enter records for updation");
	System.out.println("Enter roll number whose records are to be updated: ");
	int uroll_number=scanner.nextInt();
	System.out.println("Enter updated employee name: ");
	String uname = scanner.next();
	System.out.println("Enter updated employee percentage: ");
	int upercentage = scanner.nextInt();
	String str1 = "update student set name ='"+uname+"',percentage ='"+upercentage+"'  where roll_number = '"+uroll_number+"' ";
	 int res1=statement.executeUpdate(str1);
		
		return res1;
}
public static int removeData() throws SQLException, ClassNotFoundException
{
	Statement statement=getStatement();
	System.out.println("Enter records to be deleted:");
	System.out.println("Enter roll number whose records are to be deleted: ");
	int droll_number=scanner.nextInt();
	String str2 = "delete from student where roll_number = '"+droll_number+"' ";
	 int res2=statement.executeUpdate(str2);
		
		return res2;
}
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		char option;
		
		
	
		do
		{
		
		
		System.out.println("enter choice");
		System.out.println("1.  create data");
		System.out.println("2.  remove data");
		System.out.println("3.  update data");
		
		int choice = scanner.nextInt();
		
		
		switch(choice)
		{
		case 1:
			try {
				int res= createData();
				if(res==1) {
					System.out.println("Insert successful");
				}
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());

			}catch(SQLException e) {
				System.out.println(e.getMessage());
			}
			
			break;
		case 2:
			try {
				int res2= removeData();
				if(res2==1) {
					System.out.println("deleted successful");
				}
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());

			}catch(SQLException e) {
				System.out.println(e.getMessage());
			}
			
			break;
			
		case 3:
			try {
			int res1 = updateData();
			if(res1==1) {
				System.out.println(" update successful");
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());

		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		
		break;
		
		
		default:
			break;
		}
		 System.out.print("Want to continue? (y or n): ");  
         option = scanner.next().charAt(0);  
        

		
		
	}
	
	 while (option == 'y' || option == 'Y');

}

	
}
